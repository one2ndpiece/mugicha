mugicha

# monitoring script
execute this in venv
```
watchmedo shell-command --patterns="*.ipynb" --recursive --command='jupytext --set-formats ipynb,py:percent ${watch_src_path}'
```


```
python generate_tree.py /path/to/your/project -o output.md
```