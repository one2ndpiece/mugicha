# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.6
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %%
# %%
import json

# JSON文字列
json_str = '''
{
    "fruits": ["apple", "banana", "cherry"],
    "vegetables": ["carrot", "lettuce", "pepper"]
}
'''

# JSONをPythonオブジェクトに変換
data = json.loads(json_str)

# リストにアクセス
fruits = data['fruits']
print(fruits)  # ['apple', 'banana', 'cherry']

# 特定の要素にアクセス
print(fruits[0])  # apple

# ループで要素を取得
for fruit in fruits:
    print(fruit)




# %%
# %%
from git import Repo
from rich.tree import Tree
import os

def get_git_files(repo_path="."):
    """GitPythonを使って管理対象ファイルを取得"""
    repo = Repo(repo_path)
    if repo.bare:
        raise Exception("This is not a Git repository.")
    return repo.git.ls_files().splitlines()

def build_rich_tree(files):
    """ファイルリストからツリー構造を構築"""
    tree = Tree("Repository")
    nodes = {}
    for file in files:
        parts = file.split("/")
        current = tree
        for part in parts[:-1]:
            if part not in nodes:
                nodes[part] = current.add(part)
            current = nodes[part]
        current.add(parts[-1])
    return tree

def main():
    """Gitファイルをツリー表示"""
    repo_path = "../"  # 現在のディレクトリをリポジトリとする
    git_files = get_git_files(repo_path)
    if not git_files:
        print("No git files found or not a git repository.")
        return

    # ツリー構築
    tree = build_rich_tree(git_files)

    # ツリーを表示
    from rich import print
    print(tree)

if __name__ == "__main__":
    main()




# %%
# %%
import pathspec

# 除外ルールを含むパターンリスト (gitignore形式)
patterns = [
    "*.txt",      # すべての .txt ファイルにマッチ
    "!important.txt", # ただし important.txt は除外
    "dir/",       # dir/ ディレクトリ以下にマッチ
    "!dir/ignore_me/", # ただし dir/ignore_me/ ディレクトリは除外
]

# PathSpecオブジェクトを作成
spec = pathspec.PathSpec.from_lines('gitwildmatch', patterns)
print("spec:", spec)

# マッチング対象のパスリスト
paths = [
    "file1.txt",
    "important.txt",
    "image.png",
    "dir/file2.txt",
    "dir/ignore_me/file3.txt",
    "other_dir/file4.txt",
    "dir/",
    "dir/ignore_me/",
]

# 各パスがパターンにマッチするか確認し、結果を出力
print("パターン:")
for pattern in patterns:
    print(f"  {pattern}")
print("\nパスとマッチ結果:")
for path in paths:
    match = spec.match_file(path)
    print(f"  '{path}': {'マッチ' if match else '非マッチ'}")



# %%
import pathspec

# サンプルのパターンリスト
patterns = [
    "*.py",      # 拡張子が .py のファイル
    "*.md",      # 拡張子が .md のファイル
    "docs/"      # docs/ で始まるパス
]

# PathSpec オブジェクトの生成（リストではなくオブジェクトが返る）
spec = pathspec.PathSpec.from_lines("gitwildmatch", patterns)

# 型の確認
print("spec の型:", type(spec))

# 内部のパターン情報を表示（PathSpec.patterns にリストとして保存されています）
print("登録されたパターン:", spec.patterns)

# サンプルのファイルリスト
files = [
    "main.py",
    "README.md",
    "setup.cfg",
    "docs/index.html",
    "docs/tutorial.txt",
    "src/app.py",
    "image.png"
]

# パターンにマッチするファイルを抽出
matched_files = list(spec.match_files(files))
print("マッチしたファイル:", matched_files)



# %%
def build_json_directory(root, file_list):
    """
    root: ルートディレクトリのパス（例："mugicha"）
    file_list: ルート以下のファイル・ディレクトリのパス一覧
               例:
               [
                   "mugicha/.devcontainer/",
                   "mugicha/.git/",
                   "mugicha/.gitattributes",
                   "mugicha/.gitignore",
                   "mugicha/.python-version",
                   "mugicha/.venv/",
                   "mugicha/README.md",
                   "mugicha/dev-only/",
                   "mugicha/mugicha.toml",
                   "mugicha/pyproject.toml",
                   "mugicha/src/main.py",
                   "mugicha/temp/",
                   "mugicha/uv.lock"
               ]
    戻り値: JSON 形式に変換したディレクトリ構造（辞書）
    """

    # 内部表現として、各ディレクトリノードは辞書とし、予約キー "__order__" に
    # 項目追加順序（そのディレクトリ内のキーのリスト）を保持する。
    # ファイルは値 None として記録する。
    tree = {"__order__": []}

    # 各パスをルートからの相対パスにして、ツリー構造に挿入する
    for path in file_list:
        # ルートのパスが末尾に "/" が付いている場合は除去
        root = root.rstrip("/")

        # ルートから始まらないものは無視
        if not path.startswith(root):
            continue

        # ルート部分を取り除く
        rel = path[len(root):]
        # 先頭に余計な "/" があれば除去
        if rel.startswith("/"):
            rel = rel[1:]
        # ディレクトリかどうかを判定（末尾が "/" ならディレクトリ）
        is_dir = path.endswith("/")
        # ディレクトリの場合は末尾の "/" を一時的に除去してパーツに分解する
        if is_dir:
            rel = rel.rstrip("/")
        if not rel:
            continue  # ルートそのものの場合

        parts = rel.split("/")

        # ツリー構造へパーツごとに挿入する
        current = tree
        for i, part in enumerate(parts):
            if i == len(parts) - 1:
                # 最後のパーツ：ディレクトリかファイルかで分ける
                if is_dir:
                    # ディレクトリの場合：まだ存在しなければ作成
                    if part not in current:
                        current[part] = {"__order__": []}
                        current["__order__"].append(part)
                else:
                    # ファイルの場合：ファイルとして登録
                    if part not in current:
                        current[part] = None
                        current["__order__"].append(part)
            else:
                # 中間のパーツは必ずディレクトリとする
                if part not in current:
                    current[part] = {"__order__": []}
                    current["__order__"].append(part)
                current = current[part]

    # 内部のツリー構造を、目的の JSON 形式へ変換するヘルパー関数
    def convert_node(node):
        items = []
        for key in node.get("__order__", []):
            value = node[key]
            if value is None:
                # ファイルの場合は文字列として追加
                items.append(key)
            else:
                # ディレクトリの場合は、キー名に "/" を付け、内部リストを再帰変換
                items.append({key + "/": convert_node(value)})
        return items

    # ルートディレクトリ（キー名の末尾に "/" を付ける）をトップレベルの辞書とする
    return {root + "/": convert_node(tree)}


# --- 以下は動作確認用のサンプルコード ---
if __name__ == "__main__":
    file_list = [
        "mugicha/.devcontainer/",
        "mugicha/.git/",
        "mugicha/.gitattributes",
        "mugicha/.gitignore",
        "mugicha/.python-version",
        "mugicha/.venv/",
        "mugicha/README.md",
        "mugicha/dev-only/",
        "mugicha/mugicha.toml",
        "mugicha/pyproject.toml",
        "mugicha/src/main.py",
        "mugicha/temp/",
        "mugicha/uv.lock"
    ]

    import json
    directory_json = build_json_directory("mugicha", file_list)
    print(json.dumps(directory_json, indent=4, ensure_ascii=False))


# %%
def build_json_directory(root, file_list):
    """
    root: ルートディレクトリの名前（例："mugicha"）
    file_list: ルート以下のファイル・ディレクトリの相対パス一覧
            ディレクトリは末尾に "/" が付いているものとする
            例:
            [
                ".devcontainer/",
                ".git/",
                ".gitattributes",
                ".gitignore",
                ".python-version",
                ".venv/",
                "README.md",
                "dev-only/",
                "mugicha.toml",
                "pyproject.toml",
                "src/main.py",
                "temp/",
                "uv.lock"
            ]
    戻り値: 指定の形式のディレクトリ構造を表現した辞書
    """

    # 内部表現として、各ディレクトリは辞書で表現し、"__order__" キーで追加順序を記録する
    tree = {"__order__": []}

    for path in file_list:
        # ファイルかディレクトリか判定（末尾が "/" の場合はディレクトリ）
        is_dir = path.endswith("/")
        # ディレクトリの場合は末尾の "/" を一時的に除去してパーツに分解する
        relative_path = path.rstrip("/") if is_dir else path
        if not relative_path:
            continue  # 空文字は無視

        parts = relative_path.split("/")
        current = tree

        for i, part in enumerate(parts):
            if i == len(parts) - 1:
                # 最後のパーツ：ディレクトリ or ファイルの登録
                if is_dir:
                    if part not in current:
                        current[part] = {"__order__": []}
                        current["__order__"].append(part)
                else:
                    if part not in current:
                        current[part] = None  # ファイルの場合は値を None とする
                        current["__order__"].append(part)
            else:
                # 中間パーツは必ずディレクトリ
                if part not in current:
                    current[part] = {"__order__": []}
                    current["__order__"].append(part)
                current = current[part]

    # 内部ツリー構造を目的の形式に変換するためのヘルパー関数
    def convert_node(node):
        items = []
        for key in node.get("__order__", []):
            value = node[key]
            if value is None:
                # ファイルの場合はそのまま文字列として追加
                items.append(key)
            else:
                # ディレクトリの場合は、キー名に "/" を付け、その中身を再帰的に変換
                items.append({key + "/": convert_node(value)})
        return items

    # ルートディレクトリをキー（末尾に "/" を付ける）とする
    return {root + "/": convert_node(tree)}


# --- 動作確認用のサンプルコード ---
if __name__ == "__main__":
    file_list = [
        ".devcontainer/",
        ".git/",
        ".gitattributes",
        ".gitignore",
        ".python-version",
        ".venv/",
        "README.md",
        "dev-only/",
        "mugicha.toml",
        "pyproject.toml",
        "src/main.py",
        "temp/",
        "uv.lock"
    ]

    import json
    directory_json = build_json_directory("mugicha", file_list)
    print(json.dumps(directory_json, indent=4, ensure_ascii=False))


# %%
import os

def get_last_directory(root):
    # os.path.normpathで末尾の余計な区切り文字（/）を除去し、
    # os.path.basenameで最後のディレクトリ名だけを抽出する
    return os.path.basename(os.path.normpath(root))

# 使用例
absolute_root = "/home/user/mugicha/"
last_directory = get_last_directory(absolute_root)
print(last_directory)  # 出力例: mugicha

