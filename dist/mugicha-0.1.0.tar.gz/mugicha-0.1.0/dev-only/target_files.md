```json
{
    "target_files": [
        ".gitattributes",
        ".gitignore",
        ".python-version",
        "README.md",
        "dev-only/sample.ipynb",
        "mugicha.toml",
        "pyproject.toml",
        "src/main.py",
        "src/target_files.py",
        "uv.lock"
    ]
}
```