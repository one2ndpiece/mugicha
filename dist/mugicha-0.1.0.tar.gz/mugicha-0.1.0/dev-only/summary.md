
# Directory
```
{
    "mugicha/": [
        "pyproject.toml",
        {
            "src/": [
                {
                    "mugicha/": [
                        "__init__.py",
                        "build_tree.py",
                        "files.py",
                        "target_files.py"
                    ]
                }
            ]
        }
    ]
}
```

## pyproject.toml
```
[project]
name = "mugicha"
version = "0.1.0"
description = "Add your description here"
readme = "README.md"
requires-python = ">=3.9"
dependencies = [
]

[dependency-groups]
dev = [
    "gitpython>=3.1.44",
    "ipykernel>=6.29.5",
    "jupytext>=1.16.6",
    "pathspec>=0.12.1",
    "rich>=13.9.4",
    "toml>=0.10.2",
    "watchdog>=6.0.0",
]


[project.scripts]
mugicha = "mugicha:main"


[build-system]
requires = [
    "hatchling",
]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = [
    "src/mugicha",
]
```

## src/mugicha/__init__.py
```
#!/usr/bin/env python3
import os
import argparse
from target_files import get_target_files
from build_tree import build_json_directory
import json
from files import get_files_content

def main():
    parser = argparse.ArgumentParser(
        description="プロジェクト内の対象ファイル群を抽出し、Markdown ファイルに出力します。"
    )
    parser.add_argument("project_dir", help="対象プロジェクトのルートディレクトリのパス")
    parser.add_argument("-o", "--output", default="summary.md", help="出力する Markdown ファイル名")
    args = parser.parse_args()

    project_root = os.path.abspath(args.project_dir)
    target_files = get_target_files(project_root)

    print("---")
    for file in target_files:
        print(file)
    print("---")

    json_directory = build_json_directory(project_root, target_files)
    
    md_content =f"""
# Directory
```
{json.dumps(json_directory, indent=4, ensure_ascii=False)}
```

"""
    md_content += get_files_content(project_root, target_files)

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(md_content)

    print(f"Markdown ファイルが作成されました: {args.output}")


if __name__ == "__main__":
    main()
```

## src/mugicha/build_tree.py
```
import os

def build_json_directory(root, file_list):
    """
    root: ルートディレクトリの名前（例："mugicha"）
    file_list: ルート以下のファイル・ディレクトリの相対パス一覧
            ディレクトリは末尾に "/" が付いているものとする
            例:
            [
                ".devcontainer/",
                ".git/",
                ".gitattributes",
                ".gitignore",
                ".python-version",
                ".venv/",
                "README.md",
                "dev-only/",
                "mugicha.toml",
                "pyproject.toml",
                "src/main.py",
                "temp/",
                "uv.lock"
            ]
    戻り値: 指定の形式のディレクトリ構造を表現した辞書
    """
    base_root = os.path.basename(os.path.normpath(root))

    # 内部表現として、各ディレクトリは辞書で表現し、"__order__" キーで追加順序を記録する
    tree = {"__order__": []}

    for path in file_list:
        # ファイルかディレクトリか判定（末尾が "/" の場合はディレクトリ）
        is_dir = path.endswith("/")
        # ディレクトリの場合は末尾の "/" を一時的に除去してパーツに分解する
        relative_path = path.rstrip("/") if is_dir else path
        if not relative_path:
            continue  # 空文字は無視

        parts = relative_path.split("/")
        current = tree

        for i, part in enumerate(parts):
            if i == len(parts) - 1:
                # 最後のパーツ：ディレクトリ or ファイルの登録
                if is_dir:
                    if part not in current:
                        current[part] = {"__order__": []}
                        current["__order__"].append(part)
                else:
                    if part not in current:
                        current[part] = None  # ファイルの場合は値を None とする
                        current["__order__"].append(part)
            else:
                # 中間パーツは必ずディレクトリ
                if part not in current:
                    current[part] = {"__order__": []}
                    current["__order__"].append(part)
                current = current[part]

    # 内部ツリー構造を目的の形式に変換するためのヘルパー関数
    def convert_node(node):
        items = []
        for key in node.get("__order__", []):
            value = node[key]
            if value is None:
                # ファイルの場合はそのまま文字列として追加
                items.append(key)
            else:
                # ディレクトリの場合は、キー名に "/" を付け、その中身を再帰的に変換
                items.append({key + "/": convert_node(value)})
        return items

    # ルートディレクトリをキー（末尾に "/" を付ける）とする
    return {base_root + "/": convert_node(tree)}
```

## src/mugicha/files.py
```
import os

def get_files_content(project_dir, file_paths):
    """
    プロジェクトディレクトリと、プロジェクトディレクトリからの相対パスのリストを受け取り、
    各ファイルの内容を以下の形式でひとつの文字列として返します。
    
    ## File.txt
    ```
    {content}
    ```
    
    ## File2.py
    ```
    {content}
    ```
    
    ※ファイルの読み込みに失敗した場合は、エラー内容を出力します。
    """
    output_lines = []
    for rel_path in file_paths:
        full_path = os.path.join(project_dir, rel_path)
        try:
            with open(full_path, 'r', encoding='utf-8') as file:
                file_content = file.read()
        except Exception as e:
            file_content = f"ファイルの読み込みに失敗しました: {e}"
        
        output_lines.append(f"## {rel_path}")
        output_lines.append("```")
        output_lines.append(file_content.rstrip())
        output_lines.append("```")
        output_lines.append("")  # 各ファイルの間に空行を追加

    result = "\n".join(output_lines)
    content = f"""{result}"""
    return content
```

## src/mugicha/target_files.py
```
import os
import pathspec
import toml

def load_gitignore(project_root):
    """
    プロジェクトルートにある .gitignore を読み込み、
    そのパターンから pathspec オブジェクトを返します。
    存在しない場合は None を返します。
    """
    gitignore_path = os.path.join(project_root, '.gitignore')
    if os.path.exists(gitignore_path):
        with open(gitignore_path, 'r', encoding='utf-8') as f:
            # 空行やコメント行を除外してパターンを取得
            patterns = [line.rstrip() for line in f if line.strip() and not line.lstrip().startswith("#")]
        return pathspec.PathSpec.from_lines('gitwildmatch', patterns)
    return None


def load_mugicha(project_root):
    """
    プロジェクトルートにある mugicha.toml を読み込み、
    ignore 用と show 用のパターンから pathspec オブジェクトを生成して返します。
    存在しない場合は (None, None) を返します。
    
    mugicha.toml の例:
    
        ignore = ["build/", "tmp/", "*.log"]
        show   = ["tmp/important.log"]
    """
    mugicha_path = os.path.join(project_root, 'mugicha.toml')
    ignore_spec = None
    show_spec = None
    if os.path.exists(mugicha_path):
        try:
            config = toml.load(mugicha_path)
            ignore_patterns = config.get("ignore", [])
            show_patterns   = config.get("show", [])
            if isinstance(ignore_patterns, list) and ignore_patterns:
                ignore_spec = pathspec.PathSpec.from_lines('gitwildmatch', ignore_patterns)
            if isinstance(show_patterns, list) and show_patterns:
                show_spec = pathspec.PathSpec.from_lines('gitwildmatch', show_patterns)
        except Exception as e:
            print(f"mugicha.toml の読み込みエラー: {e}")
    return ignore_spec, show_spec


def get_all_files(project_root):
    """
    プロジェクト内の全ファイルの相対パス（UNIX形式）リストを返します。
    """
    file_list = []
    for dirpath, _, filenames in os.walk(project_root):
        for filename in filenames:
            full_path = os.path.join(dirpath, filename)
            rel_path = os.path.relpath(full_path, project_root)
            # OS依存のパス区切りを "/" に統一
            rel_path = rel_path.replace(os.sep, "/")
            file_list.append(rel_path)
    return file_list


def get_target_files(project_root):
    """
    ・.gitignore による除外ルールを反映して対象となるファイルのリストを取得します。
        → 全ファイル集合から、.gitignore のパターンにマッチするファイルを除外
    ・mugicha.toml の ignore ルールによる除外を反映して対象となるファイルのリストを取得します。
        → 全ファイル集合から、mugicha の ignore パターンにマッチするファイルを除外
    ・上記2つのルールの結果の共通部分（AND）を対象ファイルとします。
    ・さらに、mugicha.toml の show ルールにマッチするファイルを追加します。
    """
    all_files = get_all_files(project_root)

    # .gitignore の場合:
    gitignore_spec = load_gitignore(project_root)
    if gitignore_spec:
        # .gitignore にマッチするファイル（除外対象）
        gitignore_excluded = set(gitignore_spec.match_files(all_files))
        # 除外対象を引いたファイル群
        gitignore_target = set(all_files) - gitignore_excluded
    else:
        gitignore_target = set(all_files)

    # mugicha.toml の ignore の場合:
    mugicha_ignore_spec, mugicha_show_spec = load_mugicha(project_root)
    if mugicha_ignore_spec:
        mugicha_excluded = set(mugicha_ignore_spec.match_files(all_files))
        mugicha_target = set(all_files) - mugicha_excluded
    else:
        mugicha_target = set(all_files)

    # 両方のルールで除外されず残ったファイルの共通部分を取得
    target_files = gitignore_target.intersection(mugicha_target)

    # mugicha.toml の show ルールにマッチするファイルを追加（除外ルールを上書き）
    if mugicha_show_spec:
        mugicha_show_files = set(mugicha_show_spec.match_files(all_files))
    else:
        mugicha_show_files = set()

    target_files = target_files.union(mugicha_show_files)

    return sorted(target_files)
```
